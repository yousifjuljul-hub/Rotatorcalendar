/* ═══════════════════════════════════════════
   تذكّر الجميع — Service Worker v1.0
   Offline-first, cache-first strategy
   ═══════════════════════════════════════════ */

const CACHE_NAME = 'remember-everyone-v1';
const FONT_CACHE = 'remember-fonts-v1';

// Files to cache on install
const STATIC_ASSETS = [
  './index.html',
  './manifest.json',
  './icons/icon-192x192.png',
  './icons/icon-512x512.png'
];

// Google Fonts to cache separately
const FONT_URLS = [
  'https://fonts.googleapis.com/css2?family=Tajawal:wght@300;400;500;700;800;900&display=swap'
];

/* ── INSTALL ── */
self.addEventListener('install', event => {
  event.waitUntil(
    Promise.all([
      caches.open(CACHE_NAME).then(cache => {
        return cache.addAll(STATIC_ASSETS);
      }),
      caches.open(FONT_CACHE).then(cache => {
        return cache.addAll(FONT_URLS).catch(() => {
          // Fonts might fail offline — that's OK
        });
      })
    ]).then(() => self.skipWaiting())
  );
});

/* ── ACTIVATE ── */
self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(
        keys
          .filter(k => k !== CACHE_NAME && k !== FONT_CACHE)
          .map(k => caches.delete(k))
      )
    ).then(() => self.clients.claim())
  );
});

/* ── FETCH — Cache-first for static, network-first for fonts ── */
self.addEventListener('fetch', event => {
  const url = new URL(event.request.url);

  // Google Fonts — stale-while-revalidate
  if (url.hostname.includes('fonts.g') || url.hostname.includes('fonts.googleapis')) {
    event.respondWith(
      caches.open(FONT_CACHE).then(cache =>
        cache.match(event.request).then(cached => {
          const fetched = fetch(event.request)
            .then(response => {
              cache.put(event.request, response.clone());
              return response;
            })
            .catch(() => cached);
          return cached || fetched;
        })
      )
    );
    return;
  }

  // Everything else — cache-first
  event.respondWith(
    caches.match(event.request).then(cached => {
      if (cached) return cached;
      return fetch(event.request).then(response => {
        if (!response || response.status !== 200 || response.type === 'opaque') {
          return response;
        }
        const toCache = response.clone();
        caches.open(CACHE_NAME).then(cache => cache.put(event.request, toCache));
        return response;
      }).catch(() => {
        // Offline fallback
        if (event.request.destination === 'document') {
          return caches.match('./index.html');
        }
      });
    })
  );
});

/* ── BACKGROUND SYNC (future) ── */
self.addEventListener('sync', event => {
  if (event.tag === 'sync-data') {
    // Placeholder for future cloud sync
    console.log('[SW] Background sync triggered');
  }
});

/* ── PUSH NOTIFICATIONS (future) ── */
self.addEventListener('push', event => {
  const data = event.data ? event.data.json() : {};
  const title = data.title || 'تذكّر الجميع';
  const options = {
    body: data.body || 'لديك مناسبة قريباً!',
    icon: './icons/icon-192x192.png',
    badge: './icons/icon-72x72.png',
    dir: 'rtl',
    lang: 'ar',
    vibrate: [200, 100, 200],
    data: { url: data.url || './' }
  };
  event.waitUntil(self.registration.showNotification(title, options));
});

self.addEventListener('notificationclick', event => {
  event.notification.close();
  event.waitUntil(clients.openWindow(event.notification.data.url));
});
